import content1 from './1.webp'
import content2 from './2.webp'
import content3 from './3.webp'
import content4 from './4.webp'
import content5 from './5.webp'
import content6 from './6.webp'

import profile1 from './1profile.jpeg'
import profile2 from './2profile.jpeg'
import profile3 from './3profile.jpeg'
import profile4 from './4profile.jpeg'
import profile5 from './5profile.jpeg'
import profile6 from './6profile.jpeg'

const images = {
    content1, 
    content2, 
    content3, 
    content4, 
    content5, 
    content6, 
    profile1, 
    profile2, 
    profile3, 
    profile4,
    profile5, 
    profile6
}

export default images